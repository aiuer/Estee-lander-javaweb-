package second_webapp;

public class Good {
	private String name;
	private Integer price;
	private String type;
	private String src;
	public Good(String iname,Integer iprice,String itype,String isrc) {
		name = iname;
		price = iprice;
		type = itype;
		src = isrc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
   
}
