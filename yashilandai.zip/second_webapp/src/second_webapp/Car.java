package second_webapp;

public class Car {
	private String picpath;
	private String name;
	private String price;
	
	public Car (String picpath,String name,String price) {
		this.name = name;
		this.price = price;
		this.picpath = picpath;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicpath() {
		return picpath;
	}
	public void setPicpath(String picpath) {
		this.picpath = picpath;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

}
