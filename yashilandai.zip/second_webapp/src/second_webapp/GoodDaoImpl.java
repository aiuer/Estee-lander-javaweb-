package second_webapp;


import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import second_webapp.BaseDao;
import second_webapp.RSProcessor;
import second_webapp.GoodDao;
import second_webapp.Good;

public class GoodDaoImpl extends BaseDao implements GoodDao {
	public int countGoodByName(String name) {
		String sql = "select count(*) as good_count from goods where name=?";
		Object[] params = {name};
		
		RSProcessor countGoodByNameProcessor = new RSProcessor(){

			public Object process(ResultSet rs) throws SQLException {
				int count = 0;
				if(rs != null) {
					if(rs.next()) {
						count = rs.getInt("good_count");
					}
				}
				
				return new Integer(count);
			}

		};
		return (Integer)this.executeQuery(countGoodByNameProcessor, sql, params);
	}
	public Good findGoodByName(String name) {
		String sql = "select * from goods where name = ?";
		Object[] params = {name};
		RSProcessor getGoodByNameProcessor = new RSProcessor() {

			public Object process(ResultSet rs) throws SQLException {
				Good good = null;

				if(rs != null) {
					if(rs.next()) {
						String name = rs.getString("name");
						Integer price = rs.getInt("price");
						String type = rs.getString("type");
						String src = rs.getString("src");
						good = new Good(name, price, type, src);
					}
				}
				return good;
			}

		};
		return (Good)this.executeQuery(getGoodByNameProcessor, sql, params);
	}
	public List<Good> findGoodsByType(String name){
		String sql = "select * from goods where type = ?;";
		Object[] params = {name};

		RSProcessor getGoodsByTypeProcessor = new RSProcessor(){

			public List process(ResultSet rs) throws SQLException {
				List<Good> goods = new ArrayList<Good>();
				while(rs.next()) {
					String name = rs.getString("name");
					Integer price = rs.getInt("price");
					String type = rs.getString("type");
					String src = rs.getString("src");
					Good good = new Good(name, price, type, src);
					/*System.out.print(good);*/
					goods.add(good);
				}
				
				return goods;
			}
		};
		return (List<Good>)this.executeQuery(getGoodsByTypeProcessor, sql, params);
	}
}
