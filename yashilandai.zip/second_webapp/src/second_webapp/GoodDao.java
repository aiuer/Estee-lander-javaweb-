package second_webapp;

import java.util.List;
import second_webapp.Good;

public interface GoodDao {
	//查找
	public int countGoodByName(String name);
	public Good findGoodByName(String name);
	public List<Good> findGoodsByType(String name);
	//添加
	/*public int insert(User user);*/
}
