package second_webapp;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarDaoImpl extends BaseDao implements CarDao {

	public int countCar() {
		String sql = "select count(*) as good_count from car";
		Object[] params = {};
		RSProcessor countGoodByNameProcessor = new RSProcessor(){

			public Object process(ResultSet rs) throws SQLException {
				int count = 0;
				if(rs != null) {
					if(rs.next()) {
						count = rs.getInt("good_count");
					}
				}
				
				return new Integer(count);
			}

		};
		
		return (Integer)this.executeQuery(countGoodByNameProcessor, sql, params);
	}
	@SuppressWarnings("unchecked")
	public List<Car> findAll() {
		String sql = "select * from car";
		Object[] params = {};
		RSProcessor getcarProcessor = new RSProcessor(){

			public List process(ResultSet rs) throws SQLException {
				List<Car> cars = new ArrayList<Car>();
				
				while(rs.next()) {
					String path = rs.getString("picpath");
					String name = rs.getString("name");
					String price = rs.getString("price");
					Car car = new Car(path, name, price);
					cars.add(car);
				}
				return cars;
			}

		};
		
		return (List<Car>)this.executeQuery(getcarProcessor, sql, params);
	}

	public int insert(Car car) {
		String sql = "insert car (picpath, name, price) values(?,?,?)";
		Object[] params = {car.getPicpath(),car.getName(),car.getPrice()};
		return this.executeUpdate(sql, params);
	}
	
	@Override
	public int delete(String name) {
		String sql = "delete from car where name=?";
		Object[] params = {name};
		return this.executeUpdate(sql, params);
	}

}
