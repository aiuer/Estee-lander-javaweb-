package second_webapp;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import second_webapp.BaseDao;
import second_webapp.RSProcessor;
import second_webapp.UserDao;
import second_webapp.User;

public class UserDaoImpl extends BaseDao implements UserDao {

	public int insert(User user) {
		String sql = "insert into user(username,printname,email,password,introduction) values(?,?,?,?,?)";
		Object[] params = {user.getUsername(), user.getPrintname(), user.getEmail(), user.getPassword(), user.getIntroduction()};
		return this.executeUpdate(sql, params);
	}

	public int countUserByName(String name) {
		String sql = "select count(*) as user_count from user where username=?";
		Object[] params = {name};
		
		RSProcessor countUserByNameProcessor = new RSProcessor(){

			public Object process(ResultSet rs) throws SQLException {
				int count = 0;
				if(rs != null) {
					if(rs.next()) {
						count = rs.getInt("user_count");
					}
				}
				
				return new Integer(count);
			}

		};
		return (Integer)this.executeQuery(countUserByNameProcessor, sql, params);
	}
	
	public User findUserByName(String name) {
		String sql = "select * from user where username = ?";
		Object[] params = {name};
		RSProcessor getUserByNameProcessor = new RSProcessor() {

			public Object process(ResultSet rs) throws SQLException {
				User user = null;
				
				if(rs != null) {
					if(rs.next()) {
						String username = rs.getString("username");
						String printname = rs.getString("printname");
						String email = rs.getString("email");
						String password = rs.getString("password");
						String introduction = rs.getString("introduction");
						user = new User(username, printname, email, password, introduction);
					}
				}
				return user;
			}

		};
		
		return (User)this.executeQuery(getUserByNameProcessor, sql, params);
	}

	public Vector<User> findUsersByName(String name) {
		String sql = "select * from user where username = ?";
		Object[] params = {name};

		RSProcessor getUsersByNameProcessor = new RSProcessor(){

			public Object process(ResultSet rs) throws SQLException {
				Vector<User> users = new Vector<User>();
				
				while(rs.next()) {
					String username = rs.getString("username");
					String printname = rs.getString("printname");
					String email = rs.getString("email");
					String password = rs.getString("password");
					String introduction = rs.getString("introduction");
					User user = new User(username, printname, email, password, introduction);
					users.add(user);
				}
				return users;
			}

		};
		
		return (Vector<User>)this.executeQuery(getUsersByNameProcessor, sql, params);
	}

}
