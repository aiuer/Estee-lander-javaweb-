package second_webapp;

import java.util.List;

public interface CarDao {
	public int insert(Car car);
	public int delete(String name);
	public List<Car> findAll();
	public int countCar(); 
}
